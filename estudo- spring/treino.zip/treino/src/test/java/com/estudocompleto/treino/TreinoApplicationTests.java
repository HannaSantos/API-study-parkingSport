package com.estudocompleto.treino;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreinoApplicationTests {

	@Test
	void contextLoads() {
	}

}
