package com.estudocompleto.treino;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreinoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreinoApplication.class, args);
	}

}
